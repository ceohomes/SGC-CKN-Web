import { createClient } from '@supabase/supabase-js';

const supabaseUrl = "https://nhpcsekqvhzzxpfbmwpj.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5ocGNzZWtxdmh6enhwZmJtd3BqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5MzEzODIsImV4cCI6MjA4ODUwNzM4Mn0.09Jk21y232gvtc-Uc30IIRavzE-ThesukwT1CeNv2q8";

export const supabase = (supabaseUrl && supabaseAnonKey) 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;
